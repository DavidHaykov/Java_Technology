package telran.book;

public enum Genre {
    FANTASY, NOVEL, DETECTIVE, HISTORY;
}
