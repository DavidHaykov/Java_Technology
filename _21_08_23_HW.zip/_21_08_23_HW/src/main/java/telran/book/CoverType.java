package telran.book;

public enum CoverType {
    SOLID, SOFT;
}
