package telran.book;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDate;
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Book  implements Serializable {
    private long isbn;
    private String Author;
    private CoverType cover;
    private int pages;
    private LocalDate publishDate;
    private String title;

}
