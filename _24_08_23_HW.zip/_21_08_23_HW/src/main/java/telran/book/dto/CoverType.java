package telran.book.dto;

public enum CoverType {
    SOLID, SOFT;
}
