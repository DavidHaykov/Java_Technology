package telran.book.dto;

public enum Genre {
    FANTASY, NOVEL, DETECTIVE, HISTORY;
}
